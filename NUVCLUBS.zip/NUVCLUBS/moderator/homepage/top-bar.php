<div class="club_welcome">Welcome Moderator of <?php  echo '<span>'.$_SESSION['moderator_Club_Name'].'</span>';?></div>


<style type="text/css">
	
	.club_welcome{
		background-color: #D6D6D7;
		color: #000;
		text-align: center;
	}

	.club_welcome span{
		font-weight: bold;
	}

</style>