<div class="club_welcome">Welcome <span>Admin</span></div>


<style type="text/css">
	
	.club_welcome{
		background-color: #D6D6D7;
		color: #000;
		text-align: center;
	}

	.club_welcome span{
		font-weight: bold;
	}

</style>