<?php 
include 'profile.php';

 ?>